Ghoulish Font by Gary Pullin. http://www.ghoulishgary.com 
Presented by http://sinisterfonts.com 

Created 2009.

Inspired by vintage horror flicks and a love of all things ghastly, "Ghoulish" is a typeface only a monster could love. Haunt your designs and layouts with this exclusive font by Rue Morgue Magazine's Art Director "Ghoulish" Gary Pullin.

This is a FREE font. Use however or for whatever you want. If you make something really cool with it, we'd love to see it. Email us at gary@ghoulishgary.com or savage@sinistervisions.com and tell us about it. If you offer it for download on your own site [WE WOULD PREFER THAT YOU DON'T], PLEASE INCLUDE THIS READ ME FILE. That's not too much to ask, is it?

This font is intended more for headlines, titles and typographical solutions. It doesn't work well for paragraphs of text, just saying.

For more free fonts and other downloadable goodies, visit http://www.sinisterfonts.com. For more samples of Gary Pullin's work, visit http://www.ghoulishgary.com .

FOR INSTRUCTIONS ON HOW TO INSTALL/USE THIS FONT, visit http://www.sinisterfonts.com, or just look it up on Google. Seriously. Don't email us and ask - this information is easily found with a 20-second search.

Thanks for your time and enjoy this exclusive typeface!

Gary Pullin and Chad Savage.
